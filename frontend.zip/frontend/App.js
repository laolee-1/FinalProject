import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoginScreen from './screens/LoginScreens';
import SignUpScreen from './screens/SignupScreens';
import HomeScreen from './screens/HomeScreens';
import ProfileScreen from './screens/ProfileScreens';
import DiscussionForumScreen from './screens/DiscussionForumScreens';
import { TouchableOpacity, Image, Alert } from 'react-native';

const Stack = createStackNavigator();

export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Login">

                <Stack.Screen 
                    name="Login" 
                    component={LoginScreen}
                    options={{
                        headerStyle: {backgroundColor: '#097969'},
                        headerTintColor: 'black',
                        title: 'Login',
                    }}
                />

                <Stack.Screen 
                    name="SignUp"
                    component={SignUpScreen}
                    options={{
                        headerStyle: {backgroundColor: '#097969'},
                        headerTintColor: 'black',
                        title: 'Sign Up',
                    }}
                />

                <Stack.Screen 
                    name="Home" 
                    component={HomeScreen}
                    options={({ route, navigation }) => {
                        // Ensure the user is fetched or passed correctly
                        const passedUser = route.params?.user || user;

                        return {
                            headerStyle: {backgroundColor: '#097969'},
                            headerTitle: () => (
                                <Image
                                    source={require('./assets/logo.png')}
                                    style={{
                                        width:60,
                                        height:50,
                                        borderRadius:20,
                                        borderWidth:1,
                                        borderColor: '#AFE1AF'
                                    }}
                                />
                            ),
                            headerTitleAlign: 'center',
                            headerRight: () => (
                                <TouchableOpacity onPress={() => navigation.navigate('Profile', { user: passedUser })}>
                                  <Image
                                    source={passedUser?.profilePicture ? { uri: `data:image/jpeg;base64,${passedUser.profilePicture}` } : require('./assets/defprofile.png')}
                                    style={{
                                      width: 40,
                                      height: 40,
                                      borderRadius: 20,
                                      borderColor: 'black',
                                      borderWidth: 1,
                                      marginRight: 10,
                                    }}
                                  />
                                </TouchableOpacity>
                            ),
                            headerBackTitleVisible: false,
                        };
                    }}
                />

                <Stack.Screen
                    name="Profile"
                    component={ProfileScreen}
                    options={{
                        headerStyle: {backgroundColor: '#097969'},
                        headerTintColor: 'black',
                        title: 'Profile',
                    }}
                />

                <Stack.Screen
                    name="DiscussionForum"
                    component={DiscussionForumScreen}
                    options={{
                        headerStyle: {backgroundColor: '#097969'},
                        headerTintColor: 'black',
                        title: 'Discussion Forum',
                    }}
                />
            </Stack.Navigator>
        </NavigationContainer>
    );
}


