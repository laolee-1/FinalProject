import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Image } from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function SignUpScreen({ navigation }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [role, setRole] = useState('trainer');

    //function to handle sign up
    const handleSignUp = async () => {
        try {
            //send POST request to the server with user details
            //replace '192.168.86.218' with your computer's IP address
            const response = await fetch('http://192.168.86.218:3000/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password, email, role }),
            });

            // Handle response
            if (response.ok) {
                Alert.alert('Success', 'User created');
                navigation.navigate('Login'); //navigate to Login
            } else {
                Alert.alert('Error', 'Sign up failed');
            }
        } catch (error) {
            Alert.alert('Error', 'An error occurred');
        }
    };

    return (
        <View style={styles.container}>
            <Image
                source={require('../assets/logo.png')}
                style={styles.logo}
            />
            <Text style={styles.singupText}>Sign Up</Text>
            <TextInput
                style={styles.input}
                placeholder="Username"
                placeholderTextColor={'white'}
                value={username}
                onChangeText={setUsername}
            />
            <TextInput
                style={styles.input}
                placeholder="Password"
                placeholderTextColor={'white'}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
            />
            <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor={'white'}
                value={email}
                onChangeText={setEmail}
            />
            <Picker
                selectedValue={role}
                style={styles.pickerContent}
                onValueChange={(itemValue) => setRole(itemValue)}
            >
                <Picker.Item label="Trainer" value="trainer" />
                <Picker.Item label="Trainee" value="trainee" />
            </Picker>
            <View style={styles.buttonContent}>
                <Button title="Sign Up" color={'#097969'} onPress={handleSignUp} testID="signup-button" />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 14,
        backgroundColor: '#5F9EA0',
    },
    input: {
        height: 40,
        width: '100%',
        borderColor: '#AFE1AF',
        backgroundColor: '#097969',
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 8,
    },
    logo: {
        width: 200,
        height: 200,
        resizeMode: 'cover',
        borderRadius: 10,
        borderWidth: 10,
        borderColor: '#AFE1AF',
        marginBottom: 20, 
    },
    singupText: {
        fontSize: 20,
        fontStyle: 'italic',
        color: 'black',
        fontWeight: 'bold'
    },
    buttonContent: {
        width: 100,
        borderWidth: 1,
        borderColor: '#AFE1AF'
    },
    pickerContent: {
        height: 50, 
        width: 150,
    }
});


