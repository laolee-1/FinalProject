import React, { useState, useEffect } from 'react';
import { View, Text, Image, Button, Alert, StyleSheet, TextInput, Modal } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

export default function ProfileScreen({ route, navigation }) {
  const { user } = route.params || {};
  const [profileImage, setProfileImage] = useState(null);
  const [userDescription, setUserDescription] = useState('');
  const [badgesEarned, setBadgesEarned] = useState([false, false, false, false]);
  const [showBadgeModal, setShowBadgeModal] = useState(false);
  const [newBadgeIndex, setNewBadgeIndex] = useState(null);

  const badgePoints = [100, 200, 300, 400];

  const checkBadges = (points) => {
    const earnedBadges = badgesEarned.slice(); //copying current state
    let newBadgeEarned = false;

    badgePoints.forEach((point, index) => {
      if (points >= point && !earnedBadges[index]) {
        earnedBadges[index] = true;
        newBadgeEarned = true;
        setNewBadgeIndex(index); //saving the index of new badge
      }
    });

    if (newBadgeEarned) {
      setBadgesEarned(earnedBadges);
      setShowBadgeModal(true); //showing pop-up modal for new badge
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
      base64: true, // Ensure base64 is set to true
    });

    if (!result.canceled) {
      const base64Image = result.assets[0].base64;
      setProfileImage(base64Image);
      saveProfilePicture(base64Image);
    }
  };

  const saveProfilePicture = async (image) => {
    try {
      const response = await fetch('http://192.168.86.218:3000/uploadProfileImages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id, image }),
      });
  
      // Ensure the response is valid JSON
      if (!response.ok) {
        const errorResponse = await response.text();  // Use text() to capture the actual response
        throw new Error(`Failed to save profile picture: ${errorResponse}`);
      }
  
      const data = await response.json();
      Alert.alert('Success', 'Profile picture updated successfully!');
      // Update user object with the new profile picture
      user.profilePicture = image;
      navigation.setParams({ user }); // Update navigation state with new user object
    } catch (error) {
      Alert.alert('Error', `Error when saving profile picture: ${error.message}`);
    }
  };
  

  const fetchProfilePicture = async () => {
    try {
      const response = await fetch(`http://192.168.86.218:3000/profileImages/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        if (data.profileImage) {
          setProfileImage(data.profileImage);
        }
      } else {
        Alert.alert('Error', 'Failed to fetch profile picture');
      }
    } catch (error) {
      Alert.alert('Error', `Error when fetching profile picture: ${error.message}`);
    }
  };

  const fetchUserDescription = async () => {
    try {
      const response = await fetch(`http://192.168.86.218:3000/userDescription/${user.id}`);
      if (response.ok) {
        const data = await response.json();
        setUserDescription(data.userDescription || '');
      } else {
        Alert.alert('Error', 'Failed to fetch user description');
      }
    } catch (error) {
      Alert.alert('Error', `Error when fetching user description: ${error.message}`);
    }
  };

  const updateUserDescription = async () => {
    try {
      const response = await fetch(`http://192.168.86.218:3000/updateUserDescription`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId: user.id, userDescription }),
      });

      if (response.ok) {
        Alert.alert('Success', 'User description updated.');
      } else {
        const errorResponse = await response.text();
        throw new Error(`Failed to update user description: ${errorResponse}`);
      }
    } catch (error) {
      Alert.alert('Error', `Error when updatung user description: ${error.message}`);
    }
  };

  useEffect(() => {
    fetchProfilePicture();
    fetchUserDescription();

    //calling api to get total points to check for badges
    const fetchTotalPoints = async () => {
      try {
        const response = await fetch(`http://192.168.86.218:3000/traineePoints/${user.id}`);
        if (response.ok) {
          const data = await response.json();
          checkBadges(data.totalPoints);
        } else {
          Alert.alert('Error', 'Failed to fetch points');
        }
      } catch (error) {
        Alert.alert('Error', `Error when fetching points: ${error.message}`);
      }
    };

    fetchTotalPoints();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.middleContainer}>
        <View style={styles.profileContainer}>
          <View style={styles.profileTextContainer}>
            <Text style={styles.userText}>Username: {user.username}</Text>
            <Text style={styles.userText}>Email: {user.email}</Text>
            <Text style={styles.userText}>Role: {user.role}</Text>
          </View>
          <Image
            source={profileImage ? { uri: `data:image/jpeg;base64,${profileImage}` } : require('../assets/defprofile.png')}
            style={{ width: 100, height: 100, borderRadius: 50 }}
          />
        </View>
        <Button title="Pick an Image" color={'#097969'} onPress={pickImage} />

        <Text style={styles.userDescText}>About Yourself: {user.userDescription}</Text>
        <TextInput
          style={styles.descTextInput}
          placeholder="Describe yourself...."
          value={userDescription}
          onChangeText={setUserDescription}
          placeholderTextColor={'white'}
          multiline
        />
        <Button title="Update Description" color={'#097969'} onPress={updateUserDescription} />
      </View>
    
      <View style={styles.badgeContainer}>
        <Image 
          source={require('../assets/achievement.png')}
          style={{ width: 80, height: 80, borderRadius: 50, tintColor: badgesEarned[0] ? null : 'gray' }}
        />
        <Image 
          source={require('../assets/badge.png')}
          style={{ width: 80, height: 80, borderRadius: 50, tintColor: badgesEarned[1] ? null : 'gray' }}
        />
        <Image 
          source={require('../assets/target.png')}
          style={{ width: 80, height: 80, borderRadius: 50, tintColor: badgesEarned[2] ? null : 'gray' }}
        />
        <Image 
          source={require('../assets/trophy.png')}
          style={{ width: 80, height: 80, borderRadius: 50, tintColor: badgesEarned[3] ? null : 'gray' }}
        />
      </View>

      {/* modal for badge noti */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={showBadgeModal}
        onRequestClose={() => setShowBadgeModal(false)}
      >
        <View style={styles.ModalContainer}>
          <View style={styles.ModalContent}>
            <Text>CONGRATULATIONS!!!!</Text>
            {newBadgeIndex !== null && (
              <Image
                source={
                  newBadgeIndex === 0
                    ? require('../assets/achievement.png')
                    : newBadgeIndex === 1
                    ? require('../assets/badge.png')
                    : newBadgeIndex === 2
                    ? require('../assets/target.png')
                    : require('../assets/trophy.png')
                }
                style={{ width: 80, height: 80, borderRadius: 50 }}
              />
            )}
            <Text>You Have Earned a New Badge!!</Text>
            <Button title="Close" onPress={() => setShowBadgeModal(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 14,
    backgroundColor: '#5F9EA0',
    flexDirection: 'column'
  },
  middleContainer: {
    flex: 3,
    width: '100%',
    backgroundColor: '#088F8F',
    padding: 10,
    marginBottom: 10,
    borderRadius: 10,
    borderWidth: 5,
    borderColor: '#AFE1AF'
  },
  profileContainer: {
    flexDirection: 'row',
    marginBottom: 10
  },
  profileTextContainer: {
    flex: 1
  },
  descTextInput: {
    borderWidth: 1,
    width: '100%',
    borderColor: '#AFE1AF',
    backgroundColor: '#097969',
    borderWidth: 1,
    borderRadius:10,
    marginBottom: 10,
    marginTop: 10,
    paddingHorizontal: 8,
    color: 'white',
    height: 200,
    textAlignVertical: 'top',
  },
  badgeContainer: {
    flexDirection: 'row',
    backgroundColor: '#088F8F',
    width: '100%',
    borderWidth: 5,
    borderRadius: 10,
    borderColor: '#AFE1AF'
  },
  ModalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  ModalContent: {
    width: '100%',
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center'
  },
  userDescText: {
    fontSize: 16,
    marginTop: 10,
    color: 'white',
    fontStyle: 'italic'
  },
  userText: {
    fontSize: 16,
    marginBottom: 1,
    color: 'white',
    fontStyle: 'italic'
  }
});
