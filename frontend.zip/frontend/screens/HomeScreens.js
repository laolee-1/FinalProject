import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import TraineeHomeScreens from './TraineeHomeScreens';
import TrainerHomeScreens from './TrainerHomeScreens';

// HomeScreen.js
export default function HomeScreen({ route, navigation }) {
    const { user } = route.params;

    const navigateToDiscussionForum = () => {
        if (user) {
            navigation.navigate('DiscussionForum', { user });
        } else {
            console.error("User data is missing");
        }
    };

    if (user.role === 'trainee'){
        return <TraineeHomeScreens user={user} navigation={navigation} navigateToDiscussionForum={navigateToDiscussionForum} />;
    } else if (user.role === 'trainer') {
        return <TrainerHomeScreens user={user} navigation={navigation} navigateToDiscussionForum={navigateToDiscussionForum} />;
    } else {
        return (
            <View style={styles.container}>
                <Text>Role not found!!!</Text>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});

