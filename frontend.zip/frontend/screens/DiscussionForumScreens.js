import React, { useEffect, useState } from 'react';
import { View, Text, Image, Button, Alert, StyleSheet, TextInput, FlatList } from 'react-native';
import * as ImagePicker from 'expo-image-picker';

export default function DiscussionForumScreen({ route, navigation }) {
  const { user } = route.params || {}; //access user safely

  if (!user) {
      Alert.alert("Error", "User data is missing.");
      navigation.goBack(); //navigate back if user data is missing
      return null;
  }

  const [caption, setCaption] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [posts, setPosts] = useState([]);
  const [comment, setComment] = useState('');

  const fetchPosts = async () => {
    try {
      const response = await fetch('http://192.168.86.218:3000/posts');
      if (response.ok) {
        const data = await response.json();
        
        // Fetch comments for each post
        const postsWithComments = await Promise.all(
          data.posts.map(async (post) => {
            const comments = await fetchComments(post.id);
            return { ...post, comments };
          })
        );
        
        setPosts(postsWithComments);
      } else {
        const errorResponse = await response.text();
        throw new Error(`Failed to fetch posts: ${errorResponse}`);
      }
    } catch (error) {
      Alert.alert('Error', `Error when fetching posts: ${error.message}`);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchComments = async (postId) => {
    try {
      const response = await fetch(`http://192.168.86.218:3000/comments/${postId}`);
      if (response.ok) {
        const data = await response.json();
        return data.comments;
      } else {
        const errorResponse = await response.text();
        throw new Error(`Failed to fetch comments: ${errorResponse}`);
      }
    } catch (error) {
      Alert.alert('Error', 'Error when fetching comments: ${error.message}');
      return [];
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
      base64: true, // Ensure base64 is set to true
    });

    if (!result.canceled) {
      const base64Image = result.assets[0].base64;
      setSelectedImage(base64Image);
    }
  };

  const handlePost = async () => {
    if (!selectedImage) {
      Alert.alert('Please select an image');
      return;
    }

    try {
      const response = await fetch('http://192.168.86.218:3000/createPost', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.id, // Replace with the actual user ID
          image: selectedImage,
          caption,
        }),
      });

      if (response.ok) {
        Alert.alert('Success', 'Post created successfully');
        setCaption('');
        setSelectedImage(null);
        fetchPosts(); // Fetch the latest posts after user posts a new post
      } else {
        const errorResponse = await response.text();
        throw new Error(`Failed to create post: ${errorResponse}`);
      }
    } catch (error) {
      Alert.alert('Error', `Error creating post: ${error.message}`);
    }
  };

  const handleAddComment = async (postId) => {
    if (!comment.trim()) {
      Alert.alert('Please add comments');
      return;
    }

    try {
      const response = await fetch('http://192.168.86.218:3000/addComment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          postId,
          userId: user.id,
          comment,
        }),
      });

      if (response.ok) {
        setComment('');
        fetchPosts(); // Fetch the latest posts with updated comments
      } else {
        const errorResponse = await response.text();
        throw new Error(`Failed to add comment: ${errorResponse}`);
      }
    } catch (error) {
      Alert.alert('Error', `Error adding comment: ${error.message}`);
    }
  };

  const renderComment = ({ item }) => (
    <View style={styles.commentContainer}>
      <View style={styles.commentHeader}>
        <Image
          source={item.profileImage ? { uri: `data:image/jpeg;base64,${item.profileImage}` } : require('../assets/defprofile.png')}
          style={styles.profileImage}
        />
        <Text style={styles.username}>{item.username}</Text>
      </View>
      <Text style={styles.commentText}>Comments: {item.comment}</Text>
      <Text style={styles.timestamp}>{new Date(item.timestamp).toLocaleString()}</Text>
    </View>
  );

  const renderPost = ({ item }) => (
    <View style={styles.postContainer}>
      <View style={styles.postHeader}>
        <Image
          source={item.profileImage ? { uri: `data:image/jpeg;base64,${item.profileImage}` } : require('../assets/defprofile.png')}
          style={styles.profileImage}
        />
        <Text style={styles.username}>{item.username}</Text>
      </View>
      <Image
        source={{ uri: `data:image/jpeg;base64,${item.image}` }}
        style={styles.postImage}
      />
      <Text style={styles.captionText}>{item.caption}</Text>
      <Text style={styles.timestamp}>{new Date(item.timestamp).toLocaleString()}</Text>
      <TextInput
        placeholder="Add comments..."
        value={comment}
        onChangeText={setComment}
        placeholderTextColor={'white'}
        style={styles.input}
      />
      <Button title="Comment" color={'#097969'} onPress={() => handleAddComment(item.id)} />
      
      <FlatList
        data={item.comments}
        keyExtractor={(commentItem) => commentItem.id.toString()}
        renderItem={renderComment}
        style={styles.flatlist}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <TextInput
          placeholder="Write a caption..."
          value={caption}
          onChangeText={setCaption}
          placeholderTextColor={'white'}
          style={styles.input}
        />

        {selectedImage && (
          <Image
            source={{ uri: `data:image/jpeg;base64,${selectedImage}` }}
            style={styles.previewImage}
          />
        )}
        <View style={styles.buttonContainer}>
          <Button title="Pick an Image" color={'#097969'} onPress={pickImage} />
          <Button title="Post" color={'#097969'} onPress={handlePost} />
        </View>
      </View>
      
      <View style={styles.listContainer}>
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderPost}
          style={styles.flatlist}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#5F9EA0',
    flexDirection: 'column'
  },
  contentContainer: {
    flex: 2,
    width: '100%',
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#AFE1AF',
    borderRadius: 10,
    backgroundColor: '#088F8F',
  },
  listContainer: {
    flex: 4,
    width: '100%'
  },
  buttonContainer: {
    flexDirection: 'row'
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: '#AFE1AF',
    backgroundColor: '#097969',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
    color: 'white'
  },
  previewImage: {
    width: 100,
    height: 100,
    marginVertical: 5,
    borderRadius: 10,
  },
  flatlist: {
    width: '100%',
  },
  postContainer: {
    padding: 16,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#AFE1AF',
    borderRadius: 10,
    backgroundColor: '#088F8F',
  },
  postHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  profileImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  username: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    fontStyle: 'italic'
  },
  postImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginVertical: 10,
  },
  captionText: {
    fontSize: 16,
    color: 'white',
    marginVertical: 5,
  },
  timestamp: {
    fontSize: 12,
    color: 'white'
  },
  commentContainer: {
    marginTop: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#AFE1AF',
  },
  commentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  commentText: {
    fontSize: 16,
    color: 'white',
    marginVertical: 5,
  }
});











