import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, Alert, TextInput, Button, StyleSheet } from 'react-native';

export default function TrainerHomeScreen({ user, navigation, navigateToDiscussionForum }) {
    const [trainees, setTrainees] = useState([]);
    const [selectedTrainee, setSelectedTrainee] = useState(null);
    const [taskName, setTaskName] = useState('');
    const [taskDescription, setTaskDescription] = useState('');
    const [taskPoints, setTaskPoints] = useState('');
    const [tasks, setTasks] = useState([]);

    useEffect(() => {
        const fetchTrainees = async () => {
            try {
                const response = await fetch('http://192.168.86.218:3000/trainees');
                if (response.ok) {
                    const data = await response.json();
                    setTrainees(data.trainees);
                } else {
                    Alert.alert('Error', 'Failed to fetch trainees');
                }
            } catch (error) {
                Alert.alert('Error', `Error while fetching trainees: ${error.message}`);
            }
        };

        fetchTrainees();
    }, []);

    const handleSelectTrainee = (trainee) => {
        setSelectedTrainee(trainee);
        setTaskName('');
        setTaskDescription('');
        setTaskPoints('');

        fetchTasksForTrainee(trainee.id);
    };

    const fetchTasksForTrainee = async (traineeId) => {
        try {
            const response = await fetch(`http://192.168.86.218:3000/tasks/${traineeId}`);
            if (response.ok) {
                const data = await response.json();
                setTasks(data.tasks);
            } else {
                Alert.alert('Error', `Failed to fetch tasks for this trainee: ${response.statusText}`);
            }
        } catch (error) {
            Alert.alert('Error', `Error fetching tasks for this trainee: ${error.message}`);
        }
    };

    const handleCreateTask = async () => {
        if (!selectedTrainee) {
            Alert.alert('Error', 'Please select a trainee first');
            return;
        }

        try {
            const response = await fetch('http://192.168.86.218:3000/createTask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    name: taskName,
                    description: taskDescription,
                    points: taskPoints,
                    traineeId: selectedTrainee.id
                }),
            });

            if (response.ok) {
                Alert.alert('Success', `Task created for ${selectedTrainee.username}`);
                setTaskName('');
                setTaskDescription('');
                setTaskPoints('');
                fetchTasksForTrainee(selectedTrainee.id);
            } else {
                Alert.alert('Error', 'Task creation failed');
            }
        } catch (error) {
            Alert.alert('Error', `Error creating task: ${error.message}`);
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.middleContainer}>
                <Text style={styles.userText}>Welcome, {user.username}!</Text>
                <Text style={styles.selectText}>Select a Trainee:</Text>

                <FlatList
                    data={trainees}
                    keyExtractor={(item) => item.id.toString()}
                    renderItem={({ item }) => (
                        <TouchableOpacity onPress={() => handleSelectTrainee(item)} style={styles.traineeItem}>
                            <Text style={styles.userText}>{item.username}</Text>
                            {item.weight && item.height && item.desiredWeight && (
                                <View>
                                    <Text style={styles.detailsText}>Weight: {item.weight} kg</Text>
                                    <Text style={styles.detailsText}>Height: {item.height} cm</Text>
                                    <Text style={styles.detailsText}>Desired Weight: {item.desiredWeight} kg</Text>
                                    <Text style={styles.detailsText}>Total Calories: {item.totalCalories} kcal</Text>
                                </View>
                            )}
                        </TouchableOpacity>
                    )}
                />
            </View>
            <View style={styles.selectedTraineeContainer}>
                {selectedTrainee && (
                        <View style={styles.taskCreationContainer}>
                            <View style={styles.taskCreateContainer}>
                                <Text style={styles.selectText}>Creating task for {selectedTrainee.username}</Text>

                                <TextInput
                                    placeholder="Name of exercise"
                                    value={taskName}
                                    onChangeText={setTaskName}
                                    placeholderTextColor={'white'}
                                    style={styles.input}
                                />

                                <TextInput
                                    placeholder="Description of exercise"
                                    value={taskDescription}
                                    onChangeText={setTaskDescription}
                                    placeholderTextColor={'white'}
                                    style={styles.input}
                                />

                                <TextInput
                                    placeholder="Points"
                                    value={taskPoints}
                                    onChangeText={setTaskPoints}
                                    placeholderTextColor={'white'}
                                    style={styles.input}
                                    keyboardType="number-pad"
                                />

                                <Button title="Create Task" color={'#097969'} onPress={handleCreateTask} />

                            </View>

                            <View style={styles.selectedTraineeTaskContainer}>
                                <Text style={styles.selectText}>Tasks for {selectedTrainee.username}:</Text>
                                <FlatList
                                    data={tasks}
                                    keyExtractor={(item) => item.id.toString()}
                                    renderItem={({ item }) => (
                                        <View style={styles.taskItem}>
                                            <Text style={styles.taskText}>{item.name}</Text>
                                            <Text style={styles.taskText}>{item.description}</Text>
                                            <Text style={styles.taskText}>Points: {item.points}</Text>
                                        </View>
                                    )}
                                />
                            </View>
                        </View>
                )}
            </View>

            <View style={styles.Bottomcontainer}>
                <TouchableOpacity onPress={() => navigateToDiscussionForum()}>
                    <Text style={styles.navigationText}>Go to Discussion Forum</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 14,
        backgroundColor: '#5F9EA0',
        flexDirection: 'column',
    },
    middleContainer: {
        flex: 1,
        alignItems: 'flex-start',
        width: '100%',
        backgroundColor: '#088F8F',
        padding: 10,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 5,
        borderColor: '#AFE1AF',
    },
    selectedTraineeContainer: {
        flex: 1.2,
        alignItems: 'flex-start',
        width: '100%',
        backgroundColor: '#088F8F',
        padding: 10,
        marginBottom: 10,
        borderRadius: 10,
        borderWidth: 5,
        borderColor: '#AFE1AF',
    },
    traineeItem: {
        padding: 10,
        borderWidth: 1,
        borderColor: '#AFE1AF',
        width: 300
    },
    taskCreationContainer: {
        marginTop: 10,
        padding: 10,
        borderWidth: 1,
        borderColor: '#AFE1AF',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
    },
    taskCreateContainer:{
        flex: 1
    },
    selectedTraineeTaskContainer: {
        flex: 1,
        marginLeft: 20,
    },
    input: {
        width: '100%',
        height: 40,
        borderColor: '#AFE1AF',
        backgroundColor: '#097969',
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 8,
        color: 'white'
    },
    taskItem: {
        padding: 10,
        borderWidth: 1,
        borderColor: '#AFE1AF',
    },
    Bottomcontainer: {
        flex: 0.2,
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#088F8F',
        borderRadius: 10,
        borderWidth: 5,
        borderColor: '#AFE1AF'
    },
    navigationText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
    userText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
        fontStyle: 'italic'
    },
    selectText: {
        color: 'white',
        fontSize: 15,
        fontWeight: 'bold',
        fontStyle: 'italic'
    },detailsText: {
        fontSize: 16,
        marginBottom: 8,
        color: 'white'
    },
    taskText: {
        color: 'white',
        fontSize: 18,
        fontWeight: 'bold',
    },
});

