import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, Image, Animated } from 'react-native';

export default function LoginScreen({ navigation }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    //animated value for logo image to fade-in effect
    const ImageAnimate = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        //start animation 
        Animated.timing(ImageAnimate, {
            toValue: 1,
            duration: 4000,
            useNativeDriver: true,
        }).start();
    }, [ImageAnimate]);

    const handleLogin = async () => {
        try {
            //replace '192.168.86.218' with your computer's IP address
            const response = await fetch('http://192.168.86.218:3000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            if (response.ok) {
                const data = await response.json();
                Alert.alert('Success', 'Login successful');
                //fetching the profile image
                const profileImageResponse = await fetch(`http://192.168.86.218:3000/profileImages/${data.user.id}`);
                if (profileImageResponse.ok) {
                    const profileImageData = await profileImageResponse.json();
                    if (profileImageData.profileImage) {
                        data.user.profilePicture = profileImageData.profileImage;
                    }
                }
                navigation.navigate('Home', { user: data.user });
            } else {
                Alert.alert('Error', 'Invalid credentials');
            }
        } catch (error) {
            Alert.alert('Error', 'An error occurred');
        }
    };

    return (
        <View style={styles.container}>
            <Animated.Image 
                source={require('../assets/logo.png')}
                //bind opacity to animated value
                style={[styles.logo, {opacity: ImageAnimate}]}
            />
            <Text style={styles.loginText}>Login</Text>
            <TextInput
                style={styles.input}
                placeholder="Username"
                placeholderTextColor={'white'}
                value={username}
                onChangeText={setUsername}
            />
            <TextInput
                style={styles.input}
                placeholder="Password"
                placeholderTextColor={'white'}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
            />
            <View style={styles.buttonContainer} >
                <View style={styles.buttonContent}>
                    <Button title="Login" color={'#097969'} onPress={handleLogin} testID="login-button"/>
                </View>
                <View style={styles.buttonContent}>
                    <Button title="Sign Up" color={'#097969'} onPress={() => navigation.navigate('SignUp')} testID="navigate-signup-button" />
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 14,
        backgroundColor: '#5F9EA0',
    },
    input: {
        height: 40,
        width: '100%',
        borderColor: '#AFE1AF',
        backgroundColor: '#097969',
        color: 'white',
        borderWidth: 1,
        marginBottom: 12,
        paddingHorizontal: 8,
    },
    logo: {
        width: 200,
        height: 200,
        resizeMode: 'cover',
        borderRadius: 10,
        borderWidth: 10,
        borderColor: '#AFE1AF',
        marginBottom: 20,
    },
    buttonContainer: {
        flexDirection: 'row',
    },
    loginText: {
        fontSize: 20,
        fontStyle: 'italic',
        color: 'black',
        fontWeight: 'bold'
    },
    buttonContent: {
        width: 100,
        borderWidth: 1,
        borderColor: '#AFE1AF'
    }
});
