import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, FlatList, Button, Alert, TextInput, TouchableOpacity, ScrollView } from 'react-native';

export default function TraineeHomeScreens({ user, navigation, navigateToDiscussionForum }) {
    const [tasks, setTasks] = useState([]);
    const [totalPoints, setTotalPoints] = useState(0);
    const [weight, setWeight] = useState('');
    const [height, setHeight] = useState('');
    const [desiredWeight, setDesiredWeight] = useState('');
    const [foodInput, setFoodInput] = useState('');
    const [calorieResult, setCalorieResult] = useState(null);
    const [totalCalories, setTotalCalories] = useState(0);

    useEffect(() => {
        const fetchTasks = async () => {
            try {
                const response = await fetch(`http://192.168.86.218:3000/tasks/${user.id}`);
                if (response.ok) {
                    const data = await response.json();
                    setTasks(data.tasks);
                } else {
                    Alert.alert('Error', 'Failed to fetch tasks');
                }
            } catch (error) {
                Alert.alert('Error', `Error when fetching tasks: ${error.message}`);
            }
        };

        const fetchTotalPoints = async () => {
            try {
                const response = await fetch(`http://192.168.86.218:3000/traineePoints/${user.id}`);
                if (response.ok) {
                    const data = await response.json();
                    setTotalPoints(data.totalPoints);
                } else {
                    Alert.alert('Error', 'Failed to fetch points');
                }
            } catch (error) {
                Alert.alert('Error', `Error when fetching points: ${error.message}`);
            }
        };

        const fetchTraineeDetails = async () => {
            try {
                const response = await fetch(`http://192.168.86.218:3000/traineeDetails/${user.id}`);
                if (response.ok) {
                    const data = await response.json();
                    if (data.traineeDetails) {
                        setWeight(data.traineeDetails.weight.toString());
                        setHeight(data.traineeDetails.height.toString());
                        setDesiredWeight(data.traineeDetails.desiredWeight.toString());
                        setTotalCalories(data.traineeDetails.totalCalories);
                    }
                } else {
                    Alert.alert('Error', 'Failed to fetch trainee details');
                }
            } catch (error) {
                Alert.alert('Error', `Error when fetching trainee details: ${error.message}`);
            }
        };

        fetchTasks();
        fetchTotalPoints();
        fetchTraineeDetails();
    }, []);

    const handleCompleteTask = async (taskId) => {
        try {
            const response = await fetch('http://192.168.86.218:3000/completeTask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId: user.id, taskId }),
            });

            if (response.ok) {
                const updatedTasks = tasks.filter((task) => task.id !== taskId);
                setTasks(updatedTasks);

                const completedTask = tasks.find(task => task.id === taskId);
                setTotalPoints(prevPoints => prevPoints + (completedTask ? completedTask.points : 0));

                Alert.alert('Success', 'Task completed!');
            } else {
                Alert.alert('Error', 'Failed to complete task');
            } 
        } catch (error) {
            Alert.alert('Error', `Error when completing task: ${error.message}`); 
        }
    };

    const handleSaveDetails = async () => {
        try {
            const response = await fetch('http://192.168.86.218:3000/traineeDetails', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId: user.id,
                    weight: parseInt(weight, 10),
                    height: parseInt(height, 10),
                    desiredWeight: parseInt(desiredWeight, 10),
                    totalCalories: totalCalories,
                }),
            });

            if (response.ok) {
                Alert.alert('Success', 'Details saved successfully!');
            } else {
                const data = await response.json();
                Alert.alert('Error', `Failed to save details: ${data.message}`);
            }
        } catch (error) {
            Alert.alert('Error', `Error when saving details: ${error.message}`);
        }
    };

    const fetchCalories = async () => {
        try {
            const response = await fetch(`https://api.calorieninjas.com/v1/nutrition?query=${encodeURIComponent(foodInput)}`, {
                method: 'GET',
                headers: {
                    'X-Api-Key': 'gW97teh809Ml9+ZmTY5R2A==zWhyaEDGXxNr17cp',
                    'Content-Type': 'application/json',
                }
            });
    
            if (response.ok) {
                const data = await response.json();
                if (data.items && data.items.length > 0) {
                    const calories = data.items.reduce((total, item) => total + item.calories, 0);
                    setCalorieResult(calories);
                    setTotalCalories(prevCalories => prevCalories + calories); //update total calories
                } else {
                    Alert.alert('No Data', 'No nutritional data found for the input.');
                }
            } else {
                Alert.alert('Error', 'Failed to fetch calorie information');
            }
        } catch (error) {
            Alert.alert('Error', `Error when fetching calorie information: ${error.message}`);
        }
    };
    
    //deteling total calories
    const handleDeleteCalories = async () => {
        try {
            const response = await fetch('http://192.168.86.218:3000/deleteTotalCalories', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId: user.id,
                }),
            });

            if (response.ok) {
                setTotalCalories(0); //resert the state
                Alert.alert('Success', 'Calories Reset!');
            } else {
                const data = await response.json();
                Alert.alert('Error', `Failed to delete calories: ${data.message}`);
            }
        } catch (error) {
            Alert.alert('Error', `Error When deleting calories: ${error.message}`);
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.Middlecontainer}>
                <ScrollView>
                    <Text style={styles.userText}>Welcome, {user.username}!</Text>
                    <Text style={styles.detailsText}>Total Points: {totalPoints}</Text>
    
                    <Text style={styles.detailsText}>Current Weight: {weight} kg</Text>
                    <Text style={styles.detailsText}>Current Height: {height} cm</Text>
                    <Text style={styles.detailsText}>Desired Weight: {desiredWeight} kg</Text>
    
                    <TextInput
                        placeholder="Weight"
                        value={weight}
                        onChangeText={setWeight}
                        placeholderTextColor={'white'}
                        keyboardType="number-pad"
                        style={styles.input}
                    />
                    <TextInput
                        placeholder="Height"
                        value={height}
                        onChangeText={setHeight}
                        placeholderTextColor={'white'}
                        keyboardType="number-pad"
                        style={styles.input}
                    />
                    <TextInput
                        placeholder="Desired Weight"
                        value={desiredWeight}
                        onChangeText={setDesiredWeight}
                        placeholderTextColor={'white'}
                        keyboardType="number-pad"
                        style={styles.input}
                    />
                         
                    <Text style={styles.detailsText}>Total calories: {totalCalories} kcal</Text>
    
                    <TextInput
                        placeholder="Enter Food Intake"
                        value={foodInput}
                        onChangeText={setFoodInput}
                        placeholderTextColor={'white'}
                        style={styles.input}
                    />
                    <Button title="Calculate Calories" color={'#097969'} onPress={fetchCalories} />
                    {calorieResult !== null && (
                        <Text style={styles.resultText}>Total Calories: {calorieResult} kcal</Text>
                    )}
                    <Button title="Delete Total Calories" color={'#097969'} onPress={handleDeleteCalories} />
                    <Button title="Save Details" color={'#097969'} onPress={handleSaveDetails} />
                </ScrollView>
            </View>
            
            <View style={styles.flatlistContainer}>
                <Text style={styles.taskText}>This is your tasks:</Text>
                <FlatList
                    data={tasks}
                    keyExtractor={item => item.id.toString()}
                    renderItem={({ item }) => (
                        <View style={styles.taskItem}>
                            <Text style={styles.taskText}>{item.name}</Text>
                            <Text style={styles.taskText}>{item.description}</Text>
                            <Text style={styles.taskText}>Points: {item.points}</Text>
                            <Button title="Completed" color={'#097969'} onPress={() => handleCompleteTask(item.id)} />
                        </View>
                    )}
                />
            </View>
            <View style={styles.Bottomcontainer}>
                <TouchableOpacity onPress={() => navigateToDiscussionForum()}>
                    <Text style={styles.navigationText}>Go to Discussion Forum</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}

    const styles = StyleSheet.create({
        container: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            padding: 14,
            backgroundColor: '#5F9EA0',
            flexDirection: 'column',
        },
        Middlecontainer: {
            flex: 3,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            width: '100%',
            backgroundColor: '#088F8F',
            padding: 10,
            marginBottom: 10,
            borderRadius: 10,
            borderWidth: 5,
            borderColor: '#AFE1AF'
        },
        Bottomcontainer: {
            flex: 0.3,
            width: '100%',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#088F8F',
            borderRadius: 10,
            borderWidth: 5,
            borderColor: '#AFE1AF'
        },
        detailsText: {
            fontSize: 16,
            marginBottom: 8,
            color: 'white'
        },
        input: {
            height: 40,
            width: '100%',
            borderColor: '#AFE1AF',
            backgroundColor: '#097969',
            borderWidth: 1,
            marginBottom: 12,
            paddingHorizontal: 8,
            color: 'white'
        },
        taskItem: {
            padding: 10,
            borderWidth: 1,
            borderColor: '#AFE1AF',
            backgroundColor: '#478778',
        },
        navigationText: {
            color: 'white',
            fontSize: 18,
            fontWeight: 'bold',
        },
        resultText: {
            fontSize: 18,
            color: 'white',
            marginTop: 10,
        },
        flatlistContainer: {
            flex: 3,
            width: '100%',
            backgroundColor: '#088F8F',
            padding: 10,
            marginBottom: 10,
            borderRadius: 10,
            borderWidth: 5,
            borderColor: '#AFE1AF'
        },
        taskText: {
            color: 'white',
            fontSize: 18,
            fontWeight: 'bold',
        },
        userText: {
            color: 'white',
            fontSize: 18,
            fontWeight: 'bold',
            fontStyle: 'italic'
        }
    });
    