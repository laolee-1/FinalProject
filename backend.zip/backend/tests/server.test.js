const request = require('supertest');
const sqlite3 = require('sqlite3').verbose();
const app = require('../server');
let server, db;

// Initialize the database with the required tables before each test
beforeEach((done) => {
  db = new sqlite3.Database(':memory:');
  db.serialize(() => {
    db.run(`DROP TABLE IF EXISTS users`);
    db.run(`CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT,
      email TEXT,
      role TEXT
    )`, done);
  });
  server = app.listen(4000, () => done());
});

// Close the server and database connection after each test
afterEach((done) => {
  server.close(() => {
    db.close(done);
  });
});

describe('POST /signup', () => {
  it('should create a new user', async () => {
    const res = await request(server)
      .post('/signup')
      .send({
        username: `testuser_${Date.now()}`, // Ensure unique username
        password: 'password123',
        email: `testuser_${Date.now()}@example.com`, // Ensure unique email
        role: 'trainee'
      });

    console.log('Response body:', res.body);

    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('message', 'User created');
  });
});

describe('POST /login', () => {
  it('should log in an existing user', async () => {
    db.run(`INSERT INTO users (username, password, email, role) VALUES ('testuser', 'password123', 'testuser@example.com', 'trainee')`);

    const res = await request(server)
      .post('/login')
      .send({
        username: 'testuser',
        password: 'password123'
      });

    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('user');
  });
});










