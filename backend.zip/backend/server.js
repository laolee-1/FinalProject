const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

const app = express();
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
app.use(cors());

const db = new sqlite3.Database('fitnessdatabase.db');

db.serialize(() => {
  //create users table to store users info
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    email TEXT,
    userDescription TEXT,
    role TEXT
  )`);

  //create tasks table to store task info
  db.run(`CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    description TEXT,
    points INTEGER,
    traineeId INTEGER,
    FOREIGN KEY (traineeId) REFERENCES users(id)
  )`);

  //create traineePoints table to store points info
  db.run(`CREATE TABLE IF NOT EXISTS traineePoints (
    userId INTEGER,
    taskId INTEGER,
    completed INTEGER,
    pointsEarned INTEGER,
    FOREIGN KEY (userId) REFERENCES users(id),
    FOREIGN KEY (taskId) REFERENCES tasks(id)
  )`);

  //create traineeDetails table to store trainee details
  db.run(`CREATE TABLE IF NOT EXISTS traineeDetails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER UNIQUE,
    weight INTEGER,
    height INTEGER,
    desiredWeight INTEGER,
    totalCalories INTEGER DEFAULT 0,
    FOREIGN KEY (userId) REFERENCES users(id)
  )`);

  //Table to store images
  db.run(`CREATE TABLE IF NOT EXISTS profileImages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER UNIQUE,
    image BLOB,
    FOREIGN KEY (userId) REFERENCES users(id)
  )`);

  //create table to store post data such as image, caption and timestamp
  db.run(`CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER,
    image BLOB,
    caption TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id)
  )`);

  //create table to store comments on post
  db.run(`CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    postId INTEGER,
    userId INTEGER,
    comment TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (postId) REFERENCES posts(id),
    FOREIGN KEY (userId) REFERENCES users(id)
  )`)
});

// API routes and endpoints
//signup route
app.post('/signup', (req, res) => {
  const { username, password, email, role } = req.body;
  const stmt = db.prepare(`INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)`);
  stmt.run(username, password, email, role, function (err) {
    if (err) {
      return res.status(500).json({ message: 'Sign up failed', error: err.message });
    }
    res.json({ message: 'User created', id: this.lastID });
  });
  stmt.finalize();
});
//login route
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get(`SELECT * FROM users WHERE username = ? AND password = ?`, [username, password], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Login failed', error: err.message });
    }
    if (row) {
      res.json({ message: 'Login successful', user: row });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  });
});
//trainer createtask route
app.post('/createTask', (req, res) => {
  const { name, description, points, traineeId } = req.body;
  const stmt = db.prepare(`INSERT INTO tasks (name, description, points, traineeId) VALUES (?, ?, ?, ?)`);
  stmt.run(name, description, points, traineeId, function (err) {
    if (err) {
      console.error('Error creating task:', err.message);
      return res.status(500).json({ message: 'Task creation failed', error: err.message });
    }
    res.json({ message: 'Task created', id: this.lastID });
  });
  stmt.finalize();
});
//trainee completetask route
app.post('/completeTask', (req, res) => {
  const { userId, taskId } = req.body;

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    db.get(`SELECT points FROM tasks WHERE id = ?`, [taskId], (err, task) => {
      if (err) {
        db.run('ROLLBACK');
        return res.status(500).json({ message: 'Failed to complete task', error: err.message });
      }

      const points = task.points;

      const stmt = db.prepare(
        `INSERT INTO traineePoints (userId, taskId, completed, pointsEarned) VALUES (?, ?, 1, ?)`
      );
      stmt.run(userId, taskId, points, function (err) {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).json({ message: 'Failed to complete task', error: err.message });
        }

        db.run(`DELETE FROM tasks WHERE id = ?`, [taskId], function (err) {
          if (err) {
            db.run('ROLLBACK');
            return res.status(500).json({ message: 'Failed to delete task', error: err.message });
          }

          db.run('COMMIT');
          res.json({ message: 'Task completed and deleted' });
        });
      });

      stmt.finalize();
    });
  });
});
//get tasks from tasks table
app.get('/tasks/:traineeId', (req, res) => {
  const traineeId = req.params.traineeId;
  const query = `SELECT * FROM tasks WHERE traineeId = ?`;

  db.all(query, [traineeId], (err, rows) => {
    if (err) {
      console.error('Error fetching tasks:', err.message);
      return res.status(500).json({ message: 'Failed to get tasks', error: err.message });
    }
    res.json({ tasks: rows });
  });
});
//get trainee points from traineePoints table
app.get('/traineePoints/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT u.username, IFNULL(SUM(tp.pointsEarned), 0) as totalPoints 
    FROM users u 
    LEFT JOIN traineePoints tp ON u.id = tp.userId 
    WHERE u.id = ?
    GROUP BY u.username;
  `;

  db.get(query, [userId], (err, row) => {
    if (err) {
      console.error('Error fetching points:', err.message);
      return res.status(500).json({message: 'Failed to get points', error: err.message });
    }

    if (row) {
      res.json({ username: row.username, totalPoints: row.totalPoints });
    } else {
      res.json({ username: '', totalPoints: 0 });
    }
  });
});
//get list of trainees with their info
app.get('/trainees', (req, res) => {
  const query = `
    SELECT 
      u.id, 
      u.username, 
      td.weight, 
      td.height, 
      td.desiredWeight,
      td.totalCalories 
    FROM users u
    LEFT JOIN traineeDetails td ON u.id = td.userId
    WHERE u.role = 'trainee'
  `;

  db.all(query, [], (err, rows) => {
    if (err) {
      console.error('Error fetching trainees:', err.message);
      return res.status(500).json({ message: 'Failed to get trainees', error: err.message });
    }
    res.json({ trainees: rows });
  });
});


//create or update trainee details
app.post('/traineeDetails', (req, res) => {
  const { userId, weight, height, desiredWeight, totalCalories } = req.body;

  if (!userId || isNaN(weight) || isNaN(height) || isNaN(desiredWeight)) {
    return res.status(400).json({ message: 'Invalid input data' });
  }

  const query = `
    INSERT INTO traineeDetails (userId, weight, height, desiredWeight, totalCalories) 
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(userId) DO UPDATE SET 
      weight=excluded.weight, 
      height=excluded.height, 
      desiredWeight=excluded.desiredWeight,
      totalCalories=excluded.totalCalories;
  `;

  console.log("Executing query:", query, "with values:", [userId, weight, height, desiredWeight, totalCalories]);

  db.run(query, [userId, weight, height, desiredWeight, totalCalories], function (err) {
    if (err) {
      console.error('Error saving trainee details:', err.message);
      return res.status(500).json({ message: 'Failed to save trainee details', error: err.message });
    }
    res.json({ message: 'Trainee details saved', id: this.lastID });
  });
});


//get trainee details
app.get('/traineeDetails/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `SELECT * FROM traineeDetails WHERE userId = ?`;

  db.get(query, [userId], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch trainee details', error: err.message });
    }
    res.json({ traineeDetails: row });
  });
});

//upload profile images to profileImages table
app.post('/uploadProfileImages', (req, res) => {
  const { userId, image } = req.body;

  const query = `
    INSERT INTO profileImages (userId, image) 
    VALUES (?, ?) 
    ON CONFLICT(userId) 
    DO UPDATE SET image=excluded.image;
  `;

  db.run(query, [userId, image], function (err) {
    if (err) {
      console.error('Error when saving image:', err.message);
      return res.status(500).json({ message: 'Failed to save profile image', error: err.message });
    }
    res.json({ message: 'Profile image uploaded', id: this.lastID });
  });
});

//general error handler (to catch any unhandled errors)
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!', error: err.message });
});


//get profile images
app.get('/profileImages/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `SELECT image FROM profileImages WHERE userId = ?`;

  db.get(query, [userId], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to get profile image.', error: err.message });
    }
    res.json({ profileImage: row ? row.image : null });
  });
});

//update user description
app.post('/updateUserDescription', (req, res) => {
  const { userId, userDescription } = req.body;

  const query = `
    UPDATE users 
    SET userDescription = ?
    WHERE id = ?
  `;

  db.run(query, [userDescription, userId], function (err) {
    if (err) {
      console.error('Error when updating user description:', err.message);
      return res.status(500).json({ message: 'Failed to update user description', error: err.message });
    }
    res.json({ message: 'User description updated successfully' });
  });
});

//get user description
app.get('/userDescription/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `SELECT userDescription FROM users WHERE id = ?`;

  db.get(query, [userId], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to get user description.', error: err.message });
    }
    res.json({ userDescription: row ? row.userDescription : '' });
  });
});

// Creating a new post
app.post('/createPost', (req, res) => {
  const { userId, image, caption } = req.body;

  const query = `INSERT INTO posts (userId, image, caption) VALUES (?, ?, ?)`;

  db.run(query, [userId, image, caption], function (err) {
    if (err) {
      console.error('Error when creating post: ', err.message);
      return res.status(500).json({ message: 'Failed to create post', error: err.message });
    }
    res.json({ message: 'Post has been created', id: this.lastID });
  });
});

// Getting posts with user info and comments
//geting post with user info
app.get('/posts', (req, res) => {
  const query = `
    SELECT p.id, p.image, p.caption, p.timestamp, u.username, pi.image as profileImage
    FROM posts p
    JOIN users u ON p.userId = u.id
    LEFT JOIN profileImages pi ON u.id = pi.userId
    ORDER BY p.timestamp DESC
  `;

  db.all(query, [], (err, rows) => {
    if (err) {
      console.error('Error when getting posts: ', err.message);
      return res.status(500).json({ message: 'Failed to fetch posts', error: err.message });
    }
    res.json({ posts: rows });
  });
});


// Adding comments to posts
app.post('/addComment', (req, res) => {
  const { postId, userId, comment } = req.body;

  const query = `INSERT INTO comments (postId, userId, comment) VALUES (?, ?, ?)`;

  db.run(query, [postId, userId, comment], function (err) {
    if (err) {
      console.error('Error when adding comments: ', err.message);
      return res.status(500).json({ message: 'Failed to add comment', error: err.message });
    }
    res.json({ message: 'Comment has been added!', id: this.lastID });
  });
});

// Getting all the comments for a post
app.get('/comments/:postId', (req, res) => {
  const postId = req.params.postId;

  const query = `
    SELECT c.id, c.comment, c.timestamp, u.username, pi.image as profileImage
    FROM comments c
    JOIN users u ON c.userId = u.id
    LEFT JOIN profileImages pi ON u.id = pi.userId
    WHERE c.postId = ?
    ORDER BY c.timestamp ASC
  `;

  db.all(query, [postId], (err, rows) => {
    if (err) {
      console.error('Error when getting comments: ', err.message);
      return res.status(500).json({ message: 'Failed to get comments', error: err.message });
    }
    res.json({ comments: rows });
  });
});

//reset the total cal to 0
app.post('/deleteTotalCalories', (req, res) => {
  const { userId } = req.body;

  if (!userId) {
    return res.status(400).json({ message: 'Invalid input data' });
  }

  const query = `UPDATE traineeDetails SET totalCalories = 0 WHERE userId = ?`;

  db.run(query, [userId], function (err) {
    if (err) {
      console.error('Error when deleting total calories: ', err.message);
      return res.status(500).json({ message: 'Failed to delete total calories', error: err.message });
    }
    res.json({ message: 'Total calroies deleted!' });
  });
});


if (require.main === module) {
  app.listen(3000, '0.0.0.0', () => {
    console.log('Server running on port 3000');
  });
}

module.exports = app;






